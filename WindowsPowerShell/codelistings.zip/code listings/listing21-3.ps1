﻿    ConvertFrom-StringData @'
        attempting = Versuch
        connectionTo = Der anschluss an
        failed = gescheitert
        succeeded = gelungen
        starting = Ab Get-OSInfo
        ending = Ende Get-OSInfo
'@
