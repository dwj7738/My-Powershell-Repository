﻿    ConvertFrom-StringData @'
        attempting = Intentar
        connectionTo = Conexion a
        failed = fracasado
        succeeded = exito
        starting = A partir Get-OSInfo
        ending = Final Get-OSInfo
'@
